import React from 'react';
import {Redirect} from 'react-router-dom';
import {connect} from 'react-redux';
import {login} from './AuthRedux';
import {Button} from 'antd-mobile';

// 登陆验证页面
@connect(
    state => state.auth, {login}
)
class Auth extends React.Component {
    render() {
        return (
            <div>
                {this.props.isAuth ? <Redirect to="/dashboard" />:null}
                <p>你没有权限,请登录</p>
                <Button onClick={this.props.login}>登陆</Button>
            </div>
        )
    }
}

export default Auth;