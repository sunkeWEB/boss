// 定义action
const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';

//定义reduce 即规则
export function auth(state={isAuth:false,user:'李云龙'},action) {
    switch (action.type) {
        case LOGIN:
            return {...state, isAuth: true};
        case LOGOUT:
            return {...state, isAuth: false};
        default:
            return state;
    }
}

// 生成action 对dispach方法有用
export function login() {
    return {type: LOGIN};
}

export function logout() {
    return {type: LOGOUT};
}