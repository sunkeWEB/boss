import React from 'react';
import {Redirect} from 'react-router-dom';
import {connect} from 'react-redux';
import {login,getUserInfo} from './AuthRedux';
import {Button} from 'antd-mobile';

// 登陆验证页面
@connect(
    state => state.auth, {login,getUserInfo}
)
class Auth extends React.Component {
    componentWillMount () {
        this.props.getUserInfo();
    }
    render() {
        return (
            <div>
                <p>姓名:{this.props.user}</p>
                {this.props.isAuth ? <Redirect to="/dashboard"/> : null}
                <p>你没有权限,请登录</p>
                <Button onClick={this.props.login}>登陆</Button>
            </div>
        )
    }
}

export default Auth;