// 合并所有的redux 并且返回总的store
import {combineReducers} from 'redux';
import {counter} from "./reduxIndex";
import {auth} from "./AuthRedux";

export default combineReducers({counter, auth});