import axios from 'axios';
// 定义action
const LOGIN = 'LOGIN';
const LOGOUT = 'LOGOUT';
const USER_DATE = 'USER_DATE';
const init = {
    isAuth: false,
    user: '李云龙',
    age: 22
};

//定义reduce 即规则
export function auth(state = init, action) {
    console.log(state,action);
    switch (action.type) {
        case LOGIN:
            return {...state, isAuth: true};
        case LOGOUT:
            return {...state, isAuth: false};
        case USER_DATE:
            return {...state, ...action.payload};
        default:
            return state;
    }
}


export function getUserInfo() {
    // dispatch 用来通知数据做修改
    return dispatch => {
        axios.get('/find').then((res) => {
            dispatch(userData(res.data.data));
        })
    }
}

export function userData(data) {
    return {type:USER_DATE,payload:data[0]}
}

// 生成action 对dispach方法有用
export function login() {
    return {type: LOGIN};
}

export function logout() {
    return {type: LOGOUT};
}