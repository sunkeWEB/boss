import React from 'react';
import ReactDom from 'react-dom';
import {createStore, applyMiddleware, compose} from 'redux';
import {Provider} from 'react-redux';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import thunk from 'redux-thunk';
import redurce from './redurces';
import Auth from './Auth';
import Dashboard from './Dashboard';
import './config';

const store = createStore(redurce, compose(
    applyMiddleware(thunk),
    window.devToolsExtension ? window.devToolsExtension() : f => f
));


ReactDom.render((<Provider store={store}>
    <BrowserRouter>
        <div>
            <Switch>
                <Route path="/" exact component={Auth}/>
                <Route path="/dashboard" component={Dashboard}/>
                <Route render={() => <p>404 Not Fount</p>}></Route>
            </Switch>
        </div>
    </BrowserRouter>
</Provider>), document.getElementById('root'));
