import React from 'react';
import {Route, Link, Switch, Redirect} from 'react-router-dom';
import {connect} from 'react-redux';
import axios from 'axios';
import App from './App';
// 这个模块只有退出
import {logout} from './AuthRedux';
import {Button} from 'antd-mobile';
// 获取到信息 stote里面的


const Help = () => {
    return <h3>这里是帮助</h3>
};

const About = () => {
    return <h3>这里是关于</h3>
};

class Test extends React.Component {
    render() {
        console.log(this.props);
        return <p>测试{this.props.match.params.id}</p>
    }
}

@connect(state => state.auth, {logout})

class Dashboard extends React.Component {

    componentWillMount() {
        axios.get('/data').then(data=>{
            console.log(data);
        },err=>{
            console.log(`错误${err}`);
        })
    }

    render() {
        const redirect = <Redirect to="/"/>;
        let match = this.props.match;
        const app = (<div>
            <p>欢迎{this.props.user} {this.props.isAuth ? <Button onClick={this.props.logout}>注销</Button> : null}</p>
            <ul>
                <li><Link to={`${match.url}`}>首页</Link></li>
                <li><Link to={`${match.url}/help`}>帮助</Link></li>
                <li><Link to={`${match.url}/about`}>关于</Link></li>
                <li><Link to={`${match.url}/test`}>测试url</Link></li>
            </ul>
            <Switch>
                <Route path={`${match.url}`} exact component={App}/>
                <Route path={`${match.url}/help`} component={Help}/>
                <Route path={`${match.url}/about`} component={About}/>
                <Route path={`${match.url}/test`} component={Test}/>
            </Switch>
        </div>);
        return this.props.isAuth ? app : redirect;
    }

}

export default Dashboard;