const mongoose = require('mongoose');

const User = new mongoose.Schema({
   user:{
       type:String,
       require:true
   },
    age:{
       type:Number,
        require:true
    }
});

module.exports = mongoose.model('users',User);