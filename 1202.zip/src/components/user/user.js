import React from 'react';
// 用户登录的时候已经有啦数据 直接在redux中获取
import {connect} from 'react-redux';
import { Result, Icon, WhiteSpace,WingBlank,List,Button} from 'antd-mobile';

@connect(state=>state.user,{})


class User extends React.Component {

    constructor(props){
        super(props);
        this.logout = this.logout.bind(this);
    }

    logout () {
        alert("asa");
        console.log("tasda");
    }

    render() {
        const userinfo = this.props;
        const company = userinfo.company;
        const title = userinfo.title;
        const Item = List.Item;
        const Brief = List.Item.Brief;
        return (
            <WingBlank>
                <Result
                    img={<img src={require(`./../img/${userinfo.avatar}`)} style={{width:60}} />}
                    title={userinfo.user}
                    message={company?<div>{company}</div>:title?<div>{title}</div>:null} />
                <List renderHeader={() => '个人信息'} className="my-list">
                    <Item extra={userinfo.title}>{userinfo.type==='boss'?'招聘岗位':'求职岗位'}</Item>
                </List>
                <List className="my-list">
                    <Item>
                        {userinfo.desc.split('\n').map(v=>(<Brief key={v}><span style={{lineHeight:2}}>{v}</span></Brief>))}
                    </Item>
                </List>
                <WhiteSpace/><WhiteSpace/>
                <Button type="primary" onClick={this.logout}>退出</Button>
            </WingBlank>
        )
    }
}

export default User;